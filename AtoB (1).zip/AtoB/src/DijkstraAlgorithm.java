import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class DijkstraAlgorithm {
    private ArrayList<Node> visited,unvisited;
    private String filePath;

    public DijkstraAlgorithm(){
        filePath = "C:\\Users\\justi\\git\\AtoB\\src\\file.txt";
    }

    public Node shortestPath(WeightedGraph graph, String source, String destination){
        visited = new ArrayList<>();
        unvisited = graph.getNodes();
        Node sourceVertex = graph.getNodeById(source);
        Node destVertex = graph.getNodeById(destination);
        if(sourceVertex==null || destVertex==null){
            System.out.println("Can´t find Vertex");
            System.out.println("SourceVertex: "+sourceVertex);
            System.out.println("DestVertex: "+destVertex);
            return null;
        }
        sourceVertex.setShortestDistance(0);
        boolean flag = false;
        while(visited.size()<unvisited.size()){
            final Node currVertex = !flag ? sourceVertex : graph.findNearestUnvisitedNode();
            if(currVertex.equals(sourceVertex))flag = true;
            for(Edge e:currVertex.getEdges()){
                Node dest = e.getDestination();
                if(!dest.isVisited()){
                    int currShortestDist =  currVertex.getShortestDistance();
                    if(currShortestDist + e.getWeight() < dest.getShortestDistance() || dest.getShortestDistance()==-1){
                        dest.setShortestDistance(currShortestDist + e.getWeight());
                        dest.setPreviousVertex(currVertex);
                    }
                }

            }
            currVertex.setVisited(true);
            visited.add(currVertex);
        }
        return destVertex;
    }

    public void shortestPathRandom(WeightedGraph graph){
        int size = graph.getNodes().size();
        Node source = graph.getNodes().get(ThreadLocalRandom.current().nextInt(0, size));
        Node dest = graph.getNodes().get(ThreadLocalRandom.current().nextInt(0, size));

        this.shortestPath(graph, source.getId(),dest.getId());
        this.findCheapestPath(graph,source,dest);
    }

    public ArrayList<String> readFile(String path){
        ArrayList<String> lines = new ArrayList<>();
        String line;
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(path));
            while((line = bufferedReader.readLine()) != null) {
                lines.add(line);
            }
            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lines;
    }

    public void findCheapestPath(WeightedGraph graph, Node source, Node dest){
        System.out.println("From: "+source.getId());
        System.out.println("To: "+dest.getId());
        System.out.println();
        Node currVertex = dest;
        boolean foundStart = false;
        ArrayList<String> results = new ArrayList<>();
        while(!foundStart){
            String res = currVertex.getId()+"("+currVertex.getShortestDistance()/60+"min)";
            if(!currVertex.equals(source)){
                res = " -> "+res;
                currVertex = currVertex.getPreviousVertex();
            }else{
                foundStart=true;
            }
            results.add(0,res);
        }
        for (String line:results){
            System.out.println(line);
        }
    }

    public void printTask4(){
        System.out.println("Task 4");
        this.shortestPathRandom(new WeightedGraph(this.readFile(this.filePath)));
    }

    public void printTask5(){
        System.out.println("Task 5");
        this.shortestPath(new WeightedGraph(this.readFile(this.filePath)),"060192001006","060068201511").printNode();
        this.shortestPath(new WeightedGraph(this.readFile(this.filePath)),"060192001006","060066102852").printNode();
        this.shortestPath(new WeightedGraph(this.readFile(this.filePath)),"060192001006","060053301433").printNode();
        this.shortestPath(new WeightedGraph(this.readFile(this.filePath)),"060192001006","060120003653").printNode();
    }

    public static void main(String args[]){
        DijkstraAlgorithm a = new DijkstraAlgorithm();
        a.printTask4();
        a.printTask5();
    }
}
