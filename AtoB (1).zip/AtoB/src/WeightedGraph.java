import java.util.ArrayList;
import java.util.Comparator;

public class WeightedGraph {
    private ArrayList<Node> adjacencyList;

    public WeightedGraph(ArrayList<String> list) {
        adjacencyList = new ArrayList<>();
        this.createGraphFromList(list);
    }

    public Node findNearestUnvisitedNode(){
        return adjacencyList.stream()
                .filter(n -> !n.isVisited() && n.getPreviousVertex()!=null)
                .min(Comparator.comparing(Node::getShortestDistance))
                .orElse(null);
    }

    public ArrayList<Node> getNodes(){
        return this.adjacencyList;
    }

    public Node getNodeById(String id){
        for(Node node: adjacencyList){
            if(node.getId().equals(id)){
                return node;
            }
        }
        return null;
    }

    public void addEdge(String source, String destination, int weight) {
        Node sourceNode = this.getNodeById(source);
        Node destinationNode = this.getNodeById(destination);
        if(sourceNode==null){
            sourceNode = new Node(source);
            adjacencyList.add(sourceNode);
        }
        if(destinationNode==null){
            destinationNode = new Node(destination);
            adjacencyList.add(destinationNode);
        }
        sourceNode.addEdge(new Edge(destinationNode, weight));
    }

    public void printGraph(){
        for(Node node: adjacencyList){
            node.printEdges();
        }
    }

    public void createGraphFromList(ArrayList<String> list){
        String[] vertex;
        String[] n;
        for(String line: list){
            vertex = line.split(" ");
            for(int i = 1; i<vertex.length;i++){
                n =vertex[i].split(",");
                this.addEdge(vertex[0],n[0],Integer.parseInt(n[1]));
            }
        }
    }
}

