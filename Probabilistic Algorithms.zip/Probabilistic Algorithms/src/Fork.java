import java.util.Random;

public class Fork{
    private int id;
    //true if fork is available
    private boolean status;

    public Fork(int forkId){
        this.id = forkId;
        this.status = true;
    }

    public int getId(){
        return this.id;
    }

    public synchronized void free(){
        status = true;
    }

    public synchronized boolean pick(int philosopherId) throws InterruptedException{
        int counter = 0;
        int limit = new Random().nextInt(10)+5;

        while(!status){
            Thread.sleep(new Random().nextInt(100)+50);
            counter++;
            if(counter> limit){
                return false;
            }
        }

        status = false;

        return true;
    }
}