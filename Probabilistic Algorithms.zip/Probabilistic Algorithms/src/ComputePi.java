import java.util.Random;

public class ComputePi {
    private static final int r = 10; //Radius des kreises
    private static final Random rg = new Random();
    private static int pInCircle = 0; //Anzahl der Punkte, die das Kreisinnere treffen

    public static void main(String[] args) {
        computePi(100000);
    }

    private static void computePi(int nRandP) { //Je h�her die Anzahl der zuf�llig gesetzten Punkte, desto genauer wird PI angenaehert
        String actualPi = String.valueOf(Math.PI);
        double x, y;
        for(int i = 0; i < nRandP; i++) { //Nimm zuf�llige Punkte und guck, ob in Kreis liegen
            x = randN(); y = randN();
            if(inCircle(x, y)) pInCircle++;
        }
        String approxPi = String.valueOf(4*(double)pInCircle/nRandP);
        System.out.println("Approximated: " + approxPi);
        System.out.println("Actual PI:    " + Math.PI);
        int i = 0;
        //Jetzt z�hlen, auf wie viele stellen unser angen�hertes PI und das "richtige" PI gleich sind
        while(i < approxPi.length() && approxPi.charAt(i) == actualPi.charAt(i)) i++;
        System.out.println("The first "  + (i-1) + " digits were equal");
    }

    private static boolean inCircle(double x, double y) {
        return Math.pow(r - x, 2) + Math.pow(r - y, 2) < r*r;
    }

    private static double randN() { //zuf�lliger Punkt in einem Quadrat der Seitenl�nge 2r
        return rg.nextDouble() * 2*r;
    }
}