public class DiningTable {
    Philosopher[] philosophers;
    Fork[] forks;
    Thread[] threads;

    int n = 5;


    public static void main(String[] args) {
        DiningTable table = new DiningTable();
        table.init();
        table.startThinking();
    }

    public void init(){
        philosophers = new Philosopher[n];
        forks = new Fork[n];
        threads = new Thread[n];

        for(int i=0; i<n;i++){
            philosophers[i]=new Philosopher(i+1);
            forks[i]=new Fork(i+1);
        }
    }

    public void startThinking(){
        for(int i=0;i<n;i++){
            final int index = i;

            threads[i] = new Thread(new Runnable() {
                public void run(){
                    try {
                        philosophers[index].start(forks[index],(index-1>0)?forks[index -1]: forks[n-1]);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            threads[i].start();
        }
    }

}
