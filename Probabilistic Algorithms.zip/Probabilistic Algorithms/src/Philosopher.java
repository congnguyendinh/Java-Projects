import java.util.Random;

public class Philosopher{
    private int id;
    private Fork left, right;

    public Philosopher(int philosopherId){
        this.id = philosopherId;
    }

    //lifecycle methods
    public void start(Fork left, Fork right) throws InterruptedException {
        this.left = left;
        this.right = right;

        while(true){
            if(new Random().nextBoolean()){
                eat();
            }else{
                think();
            }
        }
    }

    public void think() throws InterruptedException {
        System.out.println("Philosopher "+ id+": is now thinking.");
        Thread.sleep(new Random().nextInt(1000)+100);
        System.out.println("Philosopher "+ id+": has stopped thinking.");
    }

    public void eat() throws InterruptedException {
        boolean rightFork;
        boolean leftFork;

        System.out.println("Philosopher "+ id+": is hungry and wants to eat.");

        System.out.println("Philosopher "+ id+": is picking up the Fork: "+left.getId());
        leftFork = left.pick(id);

        if(!leftFork){
            return;
        }

        System.out.println("Philosopher "+ id+": is picking up the Fork: "+right.getId());
        rightFork = right.pick(id);

        if(!rightFork){
            left.free();
            return;
        }

        System.out.println("Philosopher "+ id+": is now eating");

        Thread.sleep(new Random().nextInt(1000)+100);

        left.free();
        right.free();

        System.out.println("Philosopher "+ id+": has stopped eating and freed the Forks.");

    }
}

