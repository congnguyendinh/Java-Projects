package Stack;
import java.util.*;

public class Postfix {

	public static void main(String[] args) {
		System.out.println(infixToPostfix("1+1*2/5"));
//		System.out.println(evaluatePostfix("123+*"));
//		Stack2 testStack = new Stack2();
//		testStack.insertTestNodes();b 
//		System.out.println(testStack.toString());
//		System.out.println(testStack.pop());
//		System.out.println(testStack.toString());
		
	}
	
	public static int precedence(String op) {
		switch (op){
		    case "+":
		    case "-":
		        return 1;
		
		    case "*":
		    case "/":
		        return 2;
		
		    case "^":
		        return 3;
		    default:
		    	return -1;
		}
    }
	
	private static boolean isOperand(String s) { 
		return s.matches("[0-9]*.?[0-9]+"); 
	}
	
    private static boolean isOperator(String s) {
    	return s.matches("[-+*/^]"); 
    }
    
    public static String infixToPostfix(String infix){
        Stack stack = new Stack();
        char[] items= infix.toCharArray();
        String result2 ="";
        
        for(char item1 : items) {
        	String item = Character.toString(item1);
        	if(item!=" ") {
        		if(isOperand(item)) {
        			result2+=item;
        		}else if(item.equals("(")) {
        			stack.push(item);
        		}else if(item.equals(")")) {
                    while(!stack.peek().equals("(")) {
                    	result2+=stack.pop();
                    }
                    stack.pop();
                } else if(isOperator(item)) {
                    while(!stack.isEmpty() && precedence((String) stack.peek()) >= precedence(item)) {
                        result2+=stack.pop();
                    }
                    stack.push(item);
                }
        	}
        }
        while(!stack.isEmpty()) {
            result2+=stack.pop();
        }
        return result2;
	}
	
	public static Boolean isOperator(char op) {
		switch(op) {
		case '+':
			return true;
		case '-':
			return true;
		case '*':
			return true;
		case '/':
			return true;
		case '^':
			return true;
		default:
			return false;
		}
	}
	
	
	public static int evaluatePostfix(String pfx){
		Stack s = new Stack();
		int x = 0, y = 0;
	    char[] items   = pfx.toCharArray();

	    for (char item : items) {
	      if(item >= '0' && item <='9') {
	    	  s.push((int)(item-'0'));
	      }else {
	    	  y = (int)s.pop();
	    	  x = (int)s.pop();
	    	  switch(item) {
	    	  	case '+':
	    	  		s.push(x+y);
	    	  		break;
	    	  	case '-':
	    	  		s.push(x-y);
	    	  		break;
	    	  	case '*':
	    	  		s.push(x*y);
	    	  		break;
	    	  	case '/':
	    	  		s.push(x/y);
	    	  		break;
	    	  }
	      }
	    }

	    return (int)s.pop();
	}

}
