package Stack;

class Stack{

	private Node lastNode = null;
	

	public void insertTestNodes() {
		this.push(1);
		this.push(2);
		this.push(3);
		this.push(4);
	} 
	
	public Boolean isEmpty() {
		return this.lastNode==null;
	}
	
	public String toString() {
		String result ="";
		Node curr = this.lastNode;
		 while (curr != null) {
			 result += curr.getData();
			 curr = curr.getPredessor();
		 }
		 return new StringBuilder(result).reverse().toString();
	}
	
	public void push(Object data) {
		lastNode = new Node(this.lastNode,data);
	}
	
	public Object pop(){
		Object data = null;
		if(isEmpty()) {
			System.out.println("Underflow");
		} else {
			data = this.lastNode.getData();
			this.lastNode = this.lastNode.getPredessor();		
		}
		return data;	
	}
	
	public Object peek(){
		Object data = null;
		if(isEmpty()) {
			System.out.println("Underflow");
		} else {
			data = this.lastNode.getData();
		}
		return data;
	}
}
