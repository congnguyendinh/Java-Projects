package Stack;

public class Node {


	//Vorg�ngerknoten
	private Node predessor = null;
	private Object data = null;
			
	public Node(Node predessor, Object data){
		this.predessor = predessor;
		this.data = data;
	}
			

	public Node getPredessor(){ return this.predessor; }
	public Object getData(){return this.data; }
	public void setData(Object data){ this.data = data; }
	public void setPredessor(Node node){this.predessor = node;}
}
