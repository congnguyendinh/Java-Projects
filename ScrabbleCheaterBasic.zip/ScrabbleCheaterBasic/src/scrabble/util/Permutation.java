package scrabble.util;


import java.util.Arrays;

public class Permutation {
	private String word;
	public Permutation(String word) {
		this.word = word;
	}

	@Override
	public int hashCode() {
		// TBD: implement this method
		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Permutation){
			Permutation perm1 = (Permutation)obj;
			return this.getNormalized().equals(perm1.getNormalized());
		}else{
			return false;
		}
	}

	@Override
	public String toString() {
		return "["+getNormalized()+"] "+getWord() ;
	}

	public String getNormalized() {
		char[] chars = word.toCharArray();
		Arrays.sort(chars);
		return new String(chars);
	}

	public String getWord() {
		return this.word;
	}

	public int length() {
		return this.word.length();
	}

}
