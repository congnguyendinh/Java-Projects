package scrabble.util;

import java.util.HashSet;
import java.util.Set;

public class SubSets {

	public static Set<String> getSubSets(String str) {
		// TODO Auto-generated method stub
		return new HashSet<>();
	}

}
