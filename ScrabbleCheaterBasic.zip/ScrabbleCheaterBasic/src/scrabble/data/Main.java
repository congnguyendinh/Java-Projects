package scrabble.data;

public class Main {
    public static void main(String[] args) {
        SimpleWordList list = new SimpleWordList();
        list.initFromFile("C:/Users/justi/workspaceJava/IntelliJ/ScrabbleCheaterBasic/wordlists/sowpods.txt");
        System.out.println(list.size());
    }
}
