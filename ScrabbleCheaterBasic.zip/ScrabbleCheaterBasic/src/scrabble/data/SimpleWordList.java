package scrabble.data;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class SimpleWordList implements WordList {
	private HashSet<String> validSet = new HashSet<>();
	private float time;

	public float getime(){
		return this.time;
	}

	public Set<String> getValidSet(){
		return this.validSet;
	}

	@Override
	public Set<String> validWordsUsingAllTiles(String tileRackPart) {
		long start = System.currentTimeMillis();
		permutation("", tileRackPart);
		long end = System.currentTimeMillis();
		this.time = (end - start) / 1000;
		return this.validSet;
	}

	private void permutation(String perm, String word) {
		if (word.isEmpty()) {
			if(wordList.contains(perm+word)){
				validSet.add(perm + word);
			}
		} else {
			for (int i = 0; i < word.length(); i++) {
				permutation(perm + word.charAt(i), word.substring(0, i) + word.substring(i + 1, word.length()));
			}
		}
	}

	public static void main(String[] args) {
		SimpleWordList list = new SimpleWordList();
		list.initFromFile("C:/Users/justi/workspaceJava/IntelliJ/ScrabbleCheaterBasic/wordlists/sowpods.txt");
		list.validWordsUsingAllTiles("gersind");
		System.out.println("count: "+list.getValidSet().size());
		System.out.println("valid list: "+list.getValidSet().toString());
		System.out.println("time: "+list.getime()+"s");
	}

	@Override
	public Set<String> allValidWords(String tileRack) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(String word) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addAll(Collection<String> words) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int size() {
		return wordList.size();
	}

	@Override
	public WordList initFromFile(String fileName) {
		String line;
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
			while((line = bufferedReader.readLine()) != null) {
				wordList.add(line);
			}
			bufferedReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new SimpleWordList();
	}

	@Override
	public WordList initFromFileAsSet(String fileName) throws IOException {
		String line;

		BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
		while((line = bufferedReader.readLine()) != null) {
			wordSet.add(line);
		}
		bufferedReader.close();

		return new SimpleWordList();
	}



}
