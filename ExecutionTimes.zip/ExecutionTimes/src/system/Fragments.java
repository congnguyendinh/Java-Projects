package system;

import java.util.Scanner;
import java.util.function.Supplier;

public class Fragments {
	public static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		int[] x = new int[] {1,2,3,4,5,6,7,8,9,10};
		while (true) {
			System.out.println("Enter a Fragment..");
			int frag = scanner.nextInt();
			
			 switch (frag) {
	            case 1:  fragment1(x);
	                     break;
	            case 2:  fragment2(x);
                break;
	            case 3:  fragment3(x);
                break;
	            case 4:  fragment4(x);
                break;
	            case 5:  fragment5(x);
                break;
	            case 6:  fragment6(x);
                break;
	            case 7:  fragment7(x);
                break;
	            case 0: isPrime();
	            break;
	            
	                  
	            default: System.out.println("No such Fragment");;
	                     break;
	        }
		}
		

	}

	public static void fragment1(int[] values) {
		System.out.println("fragment 1\n");
		for(int u =0; u<values.length;u++) {
			double sum=0;
			long timeStart = System.nanoTime();
			for ( int i = 0; i < values[u]; i ++) {
				sum++; 
			}
			long timeEnd = System.nanoTime();
			long result = (timeEnd - timeStart) / 1000000;
			System.out.println("n: "+values[u]+"\nsum: "+sum +"\ntime:"+result+"ms\n");
		}
	}
	
	public static void fragment2(int[] values) {
		System.out.println("fragment 2\n");
		for(int u =0; u<values.length;u++) {
			double sum=0;
			long timeStart = System.nanoTime();
			for ( int i = 0; i < values[u]; i ++)
				for ( int j = 0; j < values[u]; j ++)
					sum++;
			long timeEnd = System.nanoTime();
			long result = (timeEnd - timeStart) / 1000000;
			System.out.println("n: "+values[u]+"\nsum: "+sum +"\ntime:"+result+"ms\n");
		}
	}
	
	public static void fragment3(int[] values) {
		System.out.println("fragment 3\n");
		for(int u =0; u<values.length;u++) {
			
			double sum=0;
			long timeStart = System.nanoTime();
			for ( int i = 0; i < values[u]; i ++)
				for ( int j = i; j < values[u]; j ++)
					sum++;
			long timeEnd = System.nanoTime();
			long result = (timeEnd - timeStart) / 1000000;
			System.out.println("n: "+values[u]+"\nsum: "+sum +"\ntime:"+result+"ms\n");
		}
	}
	
	public static void fragment4(int[] values) {
		System.out.println("fragment 4\n");
		for(int u =0; u<values.length;u++) {
			
			double sum=0;
			long timeStart = System.nanoTime();
			for ( int i = 0; i < values[u]; i ++)
				sum ++;
			for ( int j = 0; j < values[u]; j ++)
				sum ++;
			long timeEnd = System.nanoTime();
			long result = (timeEnd - timeStart) / 1000000;
			System.out.println("n: "+values[u]+"\nsum: "+sum +"\ntime:"+result+"ms\n");
		}
	}
	
	public static void fragment5(int[] values) {
		System.out.println("fragment 5\n");
		for(int u =0; u<values.length;u++) {
			
			double sum=0;
			long timeStart = System.nanoTime();
			for ( int i = 0; i < values[u]; i ++)
			     for ( int j = 0; j < values[u]*values[u]; j ++)
			     sum++;
			long timeEnd = System.nanoTime();
			long result = (timeEnd - timeStart) / 1000000;
			System.out.println("n: "+values[u]+"\nsum: "+sum +"\ntime:"+result+"ms\n");
		}
	}
	
	public static void fragment6(int[] values) {
		System.out.println("fragment 6\n");
		for(int u =0; u<values.length;u++) {
			double sum=0;
			long timeStart = System.nanoTime();
			for ( int i = 0; i < values[u]; i ++) 
			     for ( int j = 0; j < i; j ++)
			         sum++;
			long timeEnd = System.nanoTime();
			long result = (timeEnd - timeStart) / 1000000;
			System.out.println("n: "+values[u]+"\nsum: "+sum +"\ntime:"+result+"ms\n");
			
		}
	}
	
	public static void fragment7(int[] values) {
		System.out.println("fragment 7\n");
		for(int u =0; u<values.length;u++) {
			
			double sum=0;
			long timeStart = System.nanoTime();
			 for ( int i = 1; i < values[u]; i ++) {
				 for ( int j = 0; j < values[u]*values[u]; j ++) {
					 if (j % i == 0) {
						 
						 for (int k = 0; k < j; k++) {
							 sum++;
							 
						 }
					 }
					 
				 }
				 
			 }
			long timeEnd = System.nanoTime();
			long result = (timeEnd - timeStart) / 1000000;
			System.out.println("n: "+values[u]+"\nsum: "+sum +"\ntime:"+result+"ms\n");
		}
	}
	
	public static void isPrime() {
		System.out.println("Enter a Number..");
		int n = 100;
		long result = 0;
		long num1 = scanner.nextLong();
		int sum = 0;
		
		for(int u = 0; u<n;u++) {
			long num = num1;
			int i = 2;
	        boolean isPrime = false;
			long timeStart = System.nanoTime();
	        while(i <= num/2){
	        	sum++; 
	            if(num % i == 0){
	                isPrime = true;
	                break;
	            }
	            ++i;
	        }
	        long timeEnd = System.nanoTime();
			result += (timeEnd - timeStart) / 1000000;
			
			System.out.println("time:"+result+"ms\n");

	        if (!isPrime)
	            System.out.println(num + " is a prime number.");
	        else
	            System.out.println(num + " is not a prime number.");
		}
		System.out.println(result+"ms");
		System.out.println("sum: "+sum);
	}
	
	
	
}


